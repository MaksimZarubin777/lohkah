module.exports = {
  OK_STATUS: 201,
  DUBLICATED_NAME: 'This name have aready in use',
  WRONG_PASSWORD_COMPARE: 'Password did not match',
  USER_WRONG_DATA: 'Mistake in name or password',
}